const http = require('http');
const fs = require('fs');
const path = require('path');

const PORT = 3000;

// Function to serve HTML files
function serveFile(filePath, contentType, response) {
    fs.readFile(filePath, (err, content) => {
        if (err) {
            response.writeHead(500, { 'Content-Type': 'text/plain' });
            response.end('500 - Internal Server Error');
        } else {
            response.writeHead(200, { 'Content-Type': contentType });
            response.end(content);
        }
    });
}

// Create the server and define routes
const server = http.createServer((req, res) => {
    let filePath = '';

    // Define routing logic
    if (req.url === '/') {
        filePath = path.join(__dirname, 'pages', 'index.html'); // Home page
    } else if (req.url === '/about') {
        filePath = path.join(__dirname, 'pages', 'about.html'); // About page
    } else if (req.url === '/contact') {
        filePath = path.join(__dirname, 'pages', 'contact.html'); // Contact page
    } else {
        filePath = path.join(__dirname, 'pages', '404.html'); // 404 page
    }

    // serve the requested file
    serveFile(filePath, 'text/html', res);
});

// Start the server
server.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});
