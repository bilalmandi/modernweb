const _ = require('lodash');

// step 1
const holidays = [
    { name: 'Christmas', date: new Date('2023-12-25') },
    { name: 'Canada Day', date: new Date('2024-07-01') },
    { name: "New Year's Day", date: new Date('2024-01-01') },
    { name: 'Thanksgiving', date: new Date('2023-10-09') }
];

// th current date
const today = new Date();

// function to calculate day until holiday
function daysUntilHoliday(holidayDate) {
    const oneDay = 24 * 60 * 60 * 1000; // hours * minutes * seconds * milliseconds

    // clone holiday date so the original not mutated
    const nextHolidayDate = new Date(holidayDate);

    //the holiday has already passed this year sets to next year
    if (nextHolidayDate < today) {
        nextHolidayDate.setFullYear(today.getFullYear() + 1);
    }

    return Math.ceil((nextHolidayDate - today) / oneDay);
}

// iterate n display number of days until each holiday
holidays.forEach(holiday => {
    console.log(`${holiday.name} is in ${daysUntilHoliday(new Date(holiday.date))} days.`);
});

// lodash to randomly pick n display a holiday
const randomHoliday = _.sample(holidays);
console.log(`Random Holiday: ${randomHoliday.name} on ${randomHoliday.date.toDateString()}`);

// lodash to find indexes of specific holidays
const christmasIndex = _.findIndex(holidays, { name: 'Christmas' });
const canadaDayIndex = _.findIndex(holidays, { name: 'Canada Day' });

console.log(`Christmas is at index: ${christmasIndex}`);
console.log(`Canada Day is at index: ${canadaDayIndex}`);
